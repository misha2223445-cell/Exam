from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import psycopg2


conn = psycopg2.connect(dbname="chalov_demo",
                        password="1111",
                        host="localhost",
                        user="postgres",
                        port="5432")
cur = conn.cursor()

entries = []
def main_window():
    def db_all():
        query = "SELECT * FROM users"
        cur.execute(query)
        return cur.fetchall()

    def db_add_peron():
        try:
            login = entries[0].get()
            password = entries[1].get()
            role = entries[2].get()
            query = "INSERT INTO users (login, password, role, block) VALUES (%s, %s, %s, %s)"
            cur.execute(query, (login, password, role, False))
            conn.commit()
        except:
            messagebox.showerror("Ошибка", "Этот логин занят!")

    def db_update(id):
        query = "UPDATE users SET login=%s, password=%s, role=%s, block=%s WHERE id=%s"
        cur.execute(query, (entries[0].get(), entries[1].get(), entries[2].get(), entries[3].get(), id))
        conn.commit()

    def add_window(edit=False):
        add_win = Tk()
        add_win.geometry("300x500")
        add_win.title("Добавить/Изменить")
        for i in range(1, 4):
            label = Label(add_win, text=f"{headers[i]}")
            label.pack()
            a = Entry(add_win)
            a.pack()
            entries.append(a)
        if not(edit):
            btn_save = Button(add_win, text="Добавить", command=db_add_peron)
            btn_save.pack(pady=20)
        else:
            label = Label(add_win, text="Блокировка")
            a = Entry(add_win)
            entries.append(a)
            label.pack()
            a.pack()
            for selected_item in tabel.selection():
                item = tabel.item(selected_item)["values"]
            for i in range(1, 5):
                entries[i - 1].insert(END, item[i])
            btn_save = Button(add_win, text="Изменить", command=lambda:db_update(item[0]))
            btn_save.pack(pady=20)


    root = Tk()
    root.title("Главное окно")
    root.geometry("1100x300")
    headers = ["ID", "login", "password", "role", "block"]
    tabel = ttk.Treeview(root, columns=headers, show="headings")
    tabel.heading("ID", text="№")
    tabel.heading("login", text="Логин")
    tabel.heading("password", text="Пароль")
    tabel.heading("role", text="Роль")
    tabel.heading("block", text="Заблокирован")
    tabel.pack()
    btn_add = Button(root, text="Добавить", command=add_window)
    btn_add.pack()
    btn_edit = Button(root, text="Изменить", command=lambda: add_window(True))
    btn_edit.pack()

    data = db_all()
    for i in data:
        tabel.insert("", END, values=i)

    root.mainloop()

if __name__ == "__main__":
    main_window()