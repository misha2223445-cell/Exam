from tkinter import *
from tkinter import messagebox, PhotoImage
import psycopg2
from main_window import main_window

try_count = 0
count_captch = 0
def auth_win():
    conn = psycopg2.connect(dbname="chalov_demo",
                            password="1111",
                            host="localhost",
                            user="postgres",
                            port="5432")
    cur = conn.cursor()
    def check_auth(login, password):
        query = """SELECT * FROM users WHERE login=%s and password=%s"""
        cur.execute(query, (login, password))
        return cur.fetchall()

    def block_user(login):
        query = """UPDATE users SET block=True WHERE login=%s"""
        cur.execute(query, (login,))
        conn.commit()

    def auth():
        global try_count, count_captch
        login = entry_login.get()
        password = entry_pass.get()
        if login and password:
            if count_captch == 3:
                data = check_auth(login, password)
                print(data)
                if data:    #Проверяем нашлось ли совпадение логина и пароля
                        if data[0][4] == True: # Проверяем не заблокирован ли пользователь
                            messagebox.showerror("Заблокирован", "Ты запломбирован!!!")
                        else:
                            messagebox.showinfo("Успешно", f"Вы авторизовались под {data[0][3]}")
                            if data[0][3] == "Администратор":
                                win.destroy()
                                main_window()
                else:
                    if try_count == 3:  # Проверка на попытки входа
                        block_user(login)  # Блокируем пользователя если количество попыток равно 3
                        try_count = 0
                        messagebox.showerror("Блокировка", "Заблокирован за 3 неправильные попытки")
                    else:
                        messagebox.showerror("Неверные данные", "Ты че нас взломать удумал?")
                        try_count += 1
            else:
                messagebox.showerror("Каптча", "Неправильно собрана каптча")
                try_count += 1
        else:
            messagebox.showerror("Ошибка!!!", "Заполните все поля!")

    def mixer():
        global count_captch
        count_captch = count_captch % 4
        img = [[image2, image3, image1, image4],
               [image3, image1, image2, image4],
               [image1, image2, image3, image4],
               [image4, image2, image3, image1]]

        label_img1.config(image=img[count_captch][0])
        label_img2.config(image=img[count_captch][1])
        label_img3.config(image=img[count_captch][2])
        label_img4.config(image=img[count_captch][3])

        count_captch += 1


    win = Tk()
    win.geometry("500x500")
    win.title("Авторизация")
    win.minsize(300, 400)
    win.maxsize(700, 700)


    image1 = PhotoImage(file="images/1.png")
    image2 = PhotoImage(file="images/2.png")
    image3 = PhotoImage(file="images/3.png")
    image4 = PhotoImage(file="images/4.png")

    main_fraim = Frame(win)

    label_login = Label(main_fraim, text="Login")
    label_pass = Label(main_fraim, text="Password")
    entry_login = Entry(main_fraim)
    entry_pass = Entry(main_fraim)
    btn_enter = Button(main_fraim, text="Enter", command=auth)
    #растягивание фрейма по всему окну, и центрирование его виджетов в центре
    main_fraim.pack(expand=True, anchor='center')
    label_login.pack()
    entry_login.pack()
    label_pass.pack()
    entry_pass.pack()
    btn_enter.pack()
    #загружаем картинки в новый фрейм
    captcha_frame = Frame(win)
    label_img1 = Label(captcha_frame, image=image4)
    label_img2 = Label(captcha_frame, image=image3)
    label_img3 = Label(captcha_frame, image=image2)
    label_img4 = Label(captcha_frame, image=image1)
    btn_mix = Button(captcha_frame, text="Перемешать", command=mixer)
    captcha_frame.pack(expand=True, anchor='center')

    label_img1.grid(row=0, column=0)
    label_img2.grid(row=0, column=1)
    label_img3.grid(row=1, column=0)
    label_img4.grid(row=1, column=1)
    btn_mix.grid(row=2, column=0, columnspan=2)

    win.mainloop()

if __name__ == "__main__":
    auth_win()