from auth_window import auth_win

auth_win()