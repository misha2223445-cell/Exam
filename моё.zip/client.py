import socket
import threading

SERVER_IP = "46.8.225.46"
PORT = 5000

nickname = "Дмитрий"

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((SERVER_IP, PORT))

running = True

def receive():
    global running
    while running:
        try:
            message = client.recv(4096).decode()
            if not message:
                break
            if message == "NICK":
                client.send(nickname.encode())
            else:
                print("\n" + message)
        except:
            print("\nСоединение потеряно")
            running = False
            break


def write():
    while True:

        text = input("> ")

        if text == "/paste":
            print("Вставьте текст.")
            print("END для отправки\n")

            lines = []
            while True:
                line = input()
                if line == "END":
                    break
                lines.append(line)

            full_text = "\n".join(lines)
            message = f"\n[{nickname}]\n{full_text}\n"
        else:
            message = f"{nickname}: {text}"

        client.send(message.encode())

receive_thread = threading.Thread(target=receive)
receive_thread.daemon = True
receive_thread.start()

print("\nПодключено к чату")
print("/paste -> вставка кода")
print("/exit -> выход\n")

write()